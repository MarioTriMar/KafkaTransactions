package com.appsdeveloperblog.estore.WithdrawalService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WithdrawalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
