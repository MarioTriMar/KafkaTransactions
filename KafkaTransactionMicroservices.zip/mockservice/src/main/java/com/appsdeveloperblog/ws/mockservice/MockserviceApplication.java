package com.appsdeveloperblog.ws.mockservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockserviceApplication.class, args);
	}

}
