package com.appsdeveloperblog.ws.mockservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
